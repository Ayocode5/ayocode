<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/studio/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'canvas.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::49LbBHx7V7Z9UlZv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'canvas.password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'canvas.password.email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'canvas.password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'canvas.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/api/stats' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IcbZMQRDVWKAuy0v',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/api/uploads' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IJlBOYuoWYVjM4v0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::avPLvVRrAIejE276',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/api/posts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YbPlJP6vuvjpbcR6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/api/posts/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VTpL54TUXJYuOx5L',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/api/tags' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bMPcuEMWFwKCcO15',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/api/tags/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9h06ks60QdXp8951',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/api/topics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mI054uWlA72p9ASw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/api/topics/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N1t9FFEVI9KVXIKu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/api/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::O0tW0eFvBn87MhUH',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/api/users/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XhpC8MrhuMWXc8vm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/api/search/posts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DkFsWwKECPFwmVss',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/api/search/tags' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::x4Ymb3uygtgWqvpD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/api/search/topics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mEF0GTQ4Z2qDKJTI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/studio/api/search/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::THQ60BsNbEq42Ogh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/broadcasting/auth' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fUeRJ0pv6WLrsyd5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N6oc2SLMW5fEgbLn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hM01KTDTQpHPBCfT',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sitemap.xml' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EmZ0KBVaAKoTffzn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/blog/api/posts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KFKNfHERdP0YdurA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/blog/api/posts/popular' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::u20WVrMu7SM7sdmE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/blog/api/posts/related' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MLhpM9nla8c9eMMS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/blog/api/posts/comment' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zu4bFfKNLbHHBbUP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Oth3iDJxuqOnjWtq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/blog/api/posts/reply' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gHKspY2hdbwp5faB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eTUlFdcwbuKfVvl3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/blog/api/tags' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nomY7tUW247H5PX7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/blog/api/topics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qJSwjRH5VXMlk8MN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/studio(?|/(?|reset\\-password/([^/]++)(*:45)|api/(?|posts/([^/]++)(?|(*:76)|/stats(*:89)|(*:96))|t(?|ags/([^/]++)(?|(*:123)|/posts(*:137)|(*:145))|opics/([^/]++)(?|(*:171)|/posts(*:185)|(*:193)))|users/([^/]++)(?|(*:220)|/posts(*:234)|(*:242))))|(?:/((?:.*)))?(*:267))|/blog(?|/api/(?|posts/([^/]++)(*:306)|t(?|ags/([^/]++)(?|(*:333)|/posts(*:347))|opics/([^/]++)(?|(*:373)|/posts(*:387)))|users/([^/]++)(?|(*:414)|/posts(*:428)))|(?:/((?:.*)))?(*:452)))/?$}sDu',
    ),
    3 => 
    array (
      45 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'canvas.password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      76 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d8aFZ1aGREhHT4Ib',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      89 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uI7btjVXkJ9d41OB',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      96 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::u4Elpj2D6I9SulhL',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tpZyWKoobWozDqCl',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      123 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tHhYGEL9mTARHXnG',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      137 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9PfHNCGMmz30Fahi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      145 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::orIMSsbig9jGG9JW',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CcM1piOSRa05fT5C',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      171 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZGRdskeJVQY7noOd',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      185 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NvYIXtkTWx2a2GP9',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      193 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jfgx0JEu9Ad35zGC',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::w8FDewiPvViUKlRi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      220 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NoQUeO9Y61G1e8iq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      234 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7G1IbLvKrij9OdjW',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      242 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XfxxRMOHOj5ANlBq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ih8OYbjD1Y9GrP07',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      267 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'canvas',
            'view' => NULL,
          ),
          1 => 
          array (
            0 => 'view',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      306 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bseXUBeaNhgQ5y6Q',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      333 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HxgS8hzzQrvoOmIt',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      347 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qr80Xe1hSckLAQrK',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      373 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VuAMIL1VJmQTssN1',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      387 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UiE0jpiAgJPWfygM',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      414 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7oy4NnKJQDhNvyAl',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      428 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::P3lTYa7Y66WOx5Bi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      452 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'blog',
            'view' => NULL,
          ),
          1 => 
          array (
            0 => 'view',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'canvas.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\Auth\\AuthenticatedSessionController@create',
        'controller' => 'Canvas\\Http\\Controllers\\Auth\\AuthenticatedSessionController@create',
        'namespace' => 'Canvas\\Http\\Controllers\\Auth',
        'prefix' => 'studio',
        'where' => 
        array (
        ),
        'as' => 'canvas.login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::49LbBHx7V7Z9UlZv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'studio/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\Auth\\AuthenticatedSessionController@store',
        'controller' => 'Canvas\\Http\\Controllers\\Auth\\AuthenticatedSessionController@store',
        'namespace' => 'Canvas\\Http\\Controllers\\Auth',
        'prefix' => 'studio',
        'where' => 
        array (
        ),
        'as' => 'generated::49LbBHx7V7Z9UlZv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'canvas.password.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\Auth\\PasswordResetLinkController@create',
        'controller' => 'Canvas\\Http\\Controllers\\Auth\\PasswordResetLinkController@create',
        'namespace' => 'Canvas\\Http\\Controllers\\Auth',
        'prefix' => 'studio',
        'where' => 
        array (
        ),
        'as' => 'canvas.password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'canvas.password.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'studio/forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\Auth\\PasswordResetLinkController@store',
        'controller' => 'Canvas\\Http\\Controllers\\Auth\\PasswordResetLinkController@store',
        'namespace' => 'Canvas\\Http\\Controllers\\Auth',
        'prefix' => 'studio',
        'where' => 
        array (
        ),
        'as' => 'canvas.password.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'canvas.password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/reset-password/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\Auth\\NewPasswordController@create',
        'controller' => 'Canvas\\Http\\Controllers\\Auth\\NewPasswordController@create',
        'namespace' => 'Canvas\\Http\\Controllers\\Auth',
        'prefix' => 'studio',
        'where' => 
        array (
        ),
        'as' => 'canvas.password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'canvas.password.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'studio/reset-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\Auth\\NewPasswordController@store',
        'controller' => 'Canvas\\Http\\Controllers\\Auth\\NewPasswordController@store',
        'namespace' => 'Canvas\\Http\\Controllers\\Auth',
        'prefix' => 'studio',
        'where' => 
        array (
        ),
        'as' => 'canvas.password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'canvas.logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\Auth\\AuthenticatedSessionController@destroy',
        'controller' => 'Canvas\\Http\\Controllers\\Auth\\AuthenticatedSessionController@destroy',
        'namespace' => 'Canvas\\Http\\Controllers\\Auth',
        'prefix' => 'studio',
        'where' => 
        array (
        ),
        'as' => 'canvas.logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::IcbZMQRDVWKAuy0v' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/stats',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\StatsController@__invoke',
        'controller' => 'Canvas\\Http\\Controllers\\StatsController',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api',
        'where' => 
        array (
        ),
        'as' => 'generated::IcbZMQRDVWKAuy0v',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::IJlBOYuoWYVjM4v0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'studio/api/uploads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\UploadsController@store',
        'controller' => 'Canvas\\Http\\Controllers\\UploadsController@store',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/uploads',
        'where' => 
        array (
        ),
        'as' => 'generated::IJlBOYuoWYVjM4v0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::avPLvVRrAIejE276' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'studio/api/uploads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\UploadsController@destroy',
        'controller' => 'Canvas\\Http\\Controllers\\UploadsController@destroy',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/uploads',
        'where' => 
        array (
        ),
        'as' => 'generated::avPLvVRrAIejE276',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YbPlJP6vuvjpbcR6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/posts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\PostController@index',
        'controller' => 'Canvas\\Http\\Controllers\\PostController@index',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/posts',
        'where' => 
        array (
        ),
        'as' => 'generated::YbPlJP6vuvjpbcR6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::VTpL54TUXJYuOx5L' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/posts/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\PostController@create',
        'controller' => 'Canvas\\Http\\Controllers\\PostController@create',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/posts',
        'where' => 
        array (
        ),
        'as' => 'generated::VTpL54TUXJYuOx5L',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::d8aFZ1aGREhHT4Ib' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/posts/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\PostController@show',
        'controller' => 'Canvas\\Http\\Controllers\\PostController@show',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/posts',
        'where' => 
        array (
        ),
        'as' => 'generated::d8aFZ1aGREhHT4Ib',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uI7btjVXkJ9d41OB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/posts/{id}/stats',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\PostController@stats',
        'controller' => 'Canvas\\Http\\Controllers\\PostController@stats',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/posts',
        'where' => 
        array (
        ),
        'as' => 'generated::uI7btjVXkJ9d41OB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::u4Elpj2D6I9SulhL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'studio/api/posts/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\PostController@store',
        'controller' => 'Canvas\\Http\\Controllers\\PostController@store',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/posts',
        'where' => 
        array (
        ),
        'as' => 'generated::u4Elpj2D6I9SulhL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tpZyWKoobWozDqCl' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'studio/api/posts/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\PostController@destroy',
        'controller' => 'Canvas\\Http\\Controllers\\PostController@destroy',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/posts',
        'where' => 
        array (
        ),
        'as' => 'generated::tpZyWKoobWozDqCl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bMPcuEMWFwKCcO15' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/tags',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\TagController@index',
        'controller' => 'Canvas\\Http\\Controllers\\TagController@index',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/tags',
        'where' => 
        array (
        ),
        'as' => 'generated::bMPcuEMWFwKCcO15',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9h06ks60QdXp8951' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/tags/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\TagController@create',
        'controller' => 'Canvas\\Http\\Controllers\\TagController@create',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/tags',
        'where' => 
        array (
        ),
        'as' => 'generated::9h06ks60QdXp8951',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tHhYGEL9mTARHXnG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/tags/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\TagController@show',
        'controller' => 'Canvas\\Http\\Controllers\\TagController@show',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/tags',
        'where' => 
        array (
        ),
        'as' => 'generated::tHhYGEL9mTARHXnG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9PfHNCGMmz30Fahi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/tags/{id}/posts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\TagController@posts',
        'controller' => 'Canvas\\Http\\Controllers\\TagController@posts',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/tags',
        'where' => 
        array (
        ),
        'as' => 'generated::9PfHNCGMmz30Fahi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::orIMSsbig9jGG9JW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'studio/api/tags/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\TagController@store',
        'controller' => 'Canvas\\Http\\Controllers\\TagController@store',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/tags',
        'where' => 
        array (
        ),
        'as' => 'generated::orIMSsbig9jGG9JW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CcM1piOSRa05fT5C' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'studio/api/tags/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\TagController@destroy',
        'controller' => 'Canvas\\Http\\Controllers\\TagController@destroy',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/tags',
        'where' => 
        array (
        ),
        'as' => 'generated::CcM1piOSRa05fT5C',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mI054uWlA72p9ASw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/topics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\TopicController@index',
        'controller' => 'Canvas\\Http\\Controllers\\TopicController@index',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/topics',
        'where' => 
        array (
        ),
        'as' => 'generated::mI054uWlA72p9ASw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::N1t9FFEVI9KVXIKu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/topics/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\TopicController@create',
        'controller' => 'Canvas\\Http\\Controllers\\TopicController@create',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/topics',
        'where' => 
        array (
        ),
        'as' => 'generated::N1t9FFEVI9KVXIKu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZGRdskeJVQY7noOd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/topics/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\TopicController@show',
        'controller' => 'Canvas\\Http\\Controllers\\TopicController@show',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/topics',
        'where' => 
        array (
        ),
        'as' => 'generated::ZGRdskeJVQY7noOd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NvYIXtkTWx2a2GP9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/topics/{id}/posts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\TopicController@posts',
        'controller' => 'Canvas\\Http\\Controllers\\TopicController@posts',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/topics',
        'where' => 
        array (
        ),
        'as' => 'generated::NvYIXtkTWx2a2GP9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jfgx0JEu9Ad35zGC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'studio/api/topics/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\TopicController@store',
        'controller' => 'Canvas\\Http\\Controllers\\TopicController@store',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/topics',
        'where' => 
        array (
        ),
        'as' => 'generated::jfgx0JEu9Ad35zGC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::w8FDewiPvViUKlRi' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'studio/api/topics/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\TopicController@destroy',
        'controller' => 'Canvas\\Http\\Controllers\\TopicController@destroy',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/topics',
        'where' => 
        array (
        ),
        'as' => 'generated::w8FDewiPvViUKlRi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::O0tW0eFvBn87MhUH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\UserController@index',
        'controller' => 'Canvas\\Http\\Controllers\\UserController@index',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/users',
        'where' => 
        array (
        ),
        'as' => 'generated::O0tW0eFvBn87MhUH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XhpC8MrhuMWXc8vm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/users/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\UserController@create',
        'controller' => 'Canvas\\Http\\Controllers\\UserController@create',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/users',
        'where' => 
        array (
        ),
        'as' => 'generated::XhpC8MrhuMWXc8vm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NoQUeO9Y61G1e8iq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/users/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\UserController@show',
        'controller' => 'Canvas\\Http\\Controllers\\UserController@show',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/users',
        'where' => 
        array (
        ),
        'as' => 'generated::NoQUeO9Y61G1e8iq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7G1IbLvKrij9OdjW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/users/{id}/posts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\UserController@posts',
        'controller' => 'Canvas\\Http\\Controllers\\UserController@posts',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/users',
        'where' => 
        array (
        ),
        'as' => 'generated::7G1IbLvKrij9OdjW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XfxxRMOHOj5ANlBq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'studio/api/users/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\UserController@store',
        'controller' => 'Canvas\\Http\\Controllers\\UserController@store',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/users',
        'where' => 
        array (
        ),
        'as' => 'generated::XfxxRMOHOj5ANlBq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ih8OYbjD1Y9GrP07' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'studio/api/users/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\UserController@destroy',
        'controller' => 'Canvas\\Http\\Controllers\\UserController@destroy',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/users',
        'where' => 
        array (
        ),
        'as' => 'generated::Ih8OYbjD1Y9GrP07',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::DkFsWwKECPFwmVss' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/search/posts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\SearchController@posts',
        'controller' => 'Canvas\\Http\\Controllers\\SearchController@posts',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/search',
        'where' => 
        array (
        ),
        'as' => 'generated::DkFsWwKECPFwmVss',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::x4Ymb3uygtgWqvpD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/search/tags',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\SearchController@tags',
        'controller' => 'Canvas\\Http\\Controllers\\SearchController@tags',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/search',
        'where' => 
        array (
        ),
        'as' => 'generated::x4Ymb3uygtgWqvpD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mEF0GTQ4Z2qDKJTI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/search/topics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\SearchController@topics',
        'controller' => 'Canvas\\Http\\Controllers\\SearchController@topics',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/search',
        'where' => 
        array (
        ),
        'as' => 'generated::mEF0GTQ4Z2qDKJTI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::THQ60BsNbEq42Ogh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/api/search/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
          2 => 'Canvas\\Http\\Middleware\\Admin',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\SearchController@users',
        'controller' => 'Canvas\\Http\\Controllers\\SearchController@users',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio/api/search',
        'where' => 
        array (
        ),
        'as' => 'generated::THQ60BsNbEq42Ogh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'canvas' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'studio/{view?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Authenticate',
        ),
        'domain' => '',
        'uses' => 'Canvas\\Http\\Controllers\\ViewController@__invoke',
        'controller' => 'Canvas\\Http\\Controllers\\ViewController',
        'namespace' => 'Canvas\\Http\\Controllers',
        'prefix' => 'studio',
        'where' => 
        array (
        ),
        'as' => 'canvas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'view' => '(.*)',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fUeRJ0pv6WLrsyd5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'broadcasting/auth',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Broadcasting\\BroadcastController@authenticate',
        'controller' => '\\Illuminate\\Broadcasting\\BroadcastController@authenticate',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'excluded_middleware' => 
        array (
          0 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
        ),
        'as' => 'generated::fUeRJ0pv6WLrsyd5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::N6oc2SLMW5fEgbLn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":289:{@Ueory+zo/WM4Ql/qSkiDY1n4bR61ZgHs1Pcx7gWgLrE=.a:5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000001cafb544000000000f450fe7";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::N6oc2SLMW5fEgbLn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hM01KTDTQpHPBCfT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":253:{@KmJe5MH8Jfi+MIhcPgZsWi21Ir4V+7IhVu5b5Axt2Is=.a:5:{s:3:"use";a:0:{}s:8:"function";s:41:"function () {
    return \\view(\'home\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000001cafb54a000000000f450fe7";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::hM01KTDTQpHPBCfT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EmZ0KBVaAKoTffzn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sitemap.xml',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\SitemapController@__invoke',
        'controller' => 'App\\Http\\Controllers\\SitemapController',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::EmZ0KBVaAKoTffzn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KFKNfHERdP0YdurA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/api/posts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PostController@posts',
        'controller' => 'App\\Http\\Controllers\\PostController@posts',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::KFKNfHERdP0YdurA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::u20WVrMu7SM7sdmE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/api/posts/popular',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PostPopularController@__invoke',
        'controller' => 'App\\Http\\Controllers\\PostPopularController',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::u20WVrMu7SM7sdmE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MLhpM9nla8c9eMMS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/api/posts/related',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PostRelatedController@__invoke',
        'controller' => 'App\\Http\\Controllers\\PostRelatedController',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::MLhpM9nla8c9eMMS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zu4bFfKNLbHHBbUP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/api/posts/comment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PostCommentController@comments',
        'controller' => 'App\\Http\\Controllers\\PostCommentController@comments',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::zu4bFfKNLbHHBbUP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gHKspY2hdbwp5faB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/api/posts/reply',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PostCommentController@replies',
        'controller' => 'App\\Http\\Controllers\\PostCommentController@replies',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::gHKspY2hdbwp5faB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Oth3iDJxuqOnjWtq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'blog/api/posts/comment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PostCommentController@saveComment',
        'controller' => 'App\\Http\\Controllers\\PostCommentController@saveComment',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::Oth3iDJxuqOnjWtq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::eTUlFdcwbuKfVvl3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'blog/api/posts/reply',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PostCommentController@saveReply',
        'controller' => 'App\\Http\\Controllers\\PostCommentController@saveReply',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::eTUlFdcwbuKfVvl3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bseXUBeaNhgQ5y6Q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/api/posts/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Canvas\\Http\\Middleware\\Session',
        ),
        'uses' => 'App\\Http\\Controllers\\PostController@showPost',
        'controller' => 'App\\Http\\Controllers\\PostController@showPost',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::bseXUBeaNhgQ5y6Q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::nomY7tUW247H5PX7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/api/tags',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PostTagController@tags',
        'controller' => 'App\\Http\\Controllers\\PostTagController@tags',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::nomY7tUW247H5PX7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HxgS8hzzQrvoOmIt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/api/tags/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PostTagController@showTag',
        'controller' => 'App\\Http\\Controllers\\PostTagController@showTag',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::HxgS8hzzQrvoOmIt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qr80Xe1hSckLAQrK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/api/tags/{slug}/posts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PostTagController@postsForTag',
        'controller' => 'App\\Http\\Controllers\\PostTagController@postsForTag',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::qr80Xe1hSckLAQrK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qJSwjRH5VXMlk8MN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/api/topics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PostTopicController@topics',
        'controller' => 'App\\Http\\Controllers\\PostTopicController@topics',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::qJSwjRH5VXMlk8MN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::VuAMIL1VJmQTssN1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/api/topics/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PostTopicController@showTopic',
        'controller' => 'App\\Http\\Controllers\\PostTopicController@showTopic',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::VuAMIL1VJmQTssN1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::UiE0jpiAgJPWfygM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/api/topics/{slug}/posts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PostTopicController@postsForTopic',
        'controller' => 'App\\Http\\Controllers\\PostTopicController@postsForTopic',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::UiE0jpiAgJPWfygM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7oy4NnKJQDhNvyAl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/api/users/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PostAuthorController@show',
        'controller' => 'App\\Http\\Controllers\\PostAuthorController@show',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::7oy4NnKJQDhNvyAl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::P3lTYa7Y66WOx5Bi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/api/users/{id}/posts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PostAuthorController@getPostsForAuthor',
        'controller' => 'App\\Http\\Controllers\\PostAuthorController@getPostsForAuthor',
        'namespace' => NULL,
        'prefix' => 'blog/api',
        'where' => 
        array (
        ),
        'as' => 'generated::P3lTYa7Y66WOx5Bi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'blog' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/{view?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\CanvasUiController@__invoke',
        'controller' => 'App\\Http\\Controllers\\CanvasUiController',
        'namespace' => NULL,
        'prefix' => '/blog',
        'where' => 
        array (
        ),
        'as' => 'blog',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'view' => '(.*)',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);

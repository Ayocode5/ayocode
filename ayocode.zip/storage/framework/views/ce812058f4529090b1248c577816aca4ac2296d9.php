<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Hello pler</title>
</head>
<body>
    <div>
        <h4>
            <?php echo e($reply->name); ?> in post <a href="#">Post ID</a> reply your comment
        </h4>
        <h4>
            <?php echo e($reply->comment); ?>

         </h4>
    </div>
</body>
</html><?php /**PATH /run/media/iyan/Data Y/Documents/Projects/Web/ayocode/resources/views/notifications/newDiscussion.blade.php ENDPATH**/ ?>
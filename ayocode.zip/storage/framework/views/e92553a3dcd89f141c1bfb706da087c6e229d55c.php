<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
</head>
<body>
    <div>
        <h4>
            <?php echo e($reply->guest->name); ?> in post <a href="https://ayocode.my.id/blog/posts/<?php echo e($reply->post_id); ?>"><?php echo e($reply->post_id); ?></a> reply your comment
        </h4>
        <div>
            <?php echo $reply->comment; ?>

        <div>
    </div>
</body>
</html><?php /**PATH /run/media/iyan/Data Y/Documents/Projects/Web/ayocode/resources/views/notifications/newPostReply.blade.php ENDPATH**/ ?>
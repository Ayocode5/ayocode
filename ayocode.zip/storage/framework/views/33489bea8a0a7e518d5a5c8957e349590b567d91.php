<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name')); ?> | Studio</title>

    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('css/app.css', 'vendor/canvas')); ?>">
    <link rel="dns-prefetch" href="//fonts.gstatic.com">

    <?php if(\Canvas\Canvas::enabledDarkMode($jsVars['user']['dark_mode'])): ?>
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/10.7.2/styles/atelier-cave-light.min.css">
    <?php else: ?>
        <link rel="stylesheet" href="//cdn.jsdelivr.net/gh/highlightjs/cdn-release@10.7.2/build/styles/sunburst.min.css">
    <?php endif; ?>

    

    <style>
        @import  url('https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap');

        body {
            font-family: 'Roboto', sans-serif;
        }

    </style>

    
    <script src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/10.7.2/highlight.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/10.7.2/languages/go.min.js"></script>
    
</head>

<body class="mb-5" <?php if(\Canvas\Canvas::enabledDarkMode($jsVars['user']['dark_mode'])): ?> data-theme="dark" <?php endif; ?>
    <?php if(\Canvas\Canvas::usingRightToLeftLanguage($jsVars['user']['locale'])): ?> data-lang="rtl" <?php endif; ?>>

    <?php if(!\Canvas\Canvas::assetsUpToDate()): ?>
    <div class="alert alert-danger border-0 text-center rounded-0 mb-0">
        <?php echo e(trans('canvas::app.assets_are_not_up_to_date')); ?>

        <?php echo e(trans('canvas::app.to_update_run')); ?><br /><code>php artisan canvas:publish</code>
    </div>
    <?php endif; ?>

    <div id="canvas">
        <router-view></router-view>
    </div>

    <script>
        window.Canvas = <?php echo json_encode($jsVars, 15, 512) ?>;

    </script>

    <script type="text/javascript" src="<?php echo e(mix('js/app.js', 'vendor/canvas')); ?>"></script>
</body>

</html>
<?php /**PATH /run/media/iyan/Data Y/Documents/Projects/Web/ayocode/vendor/austintoddj/canvas/src/../resources/views/layout.blade.php ENDPATH**/ ?>
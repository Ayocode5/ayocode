<?php echo e($slot); ?>

<?php /**PATH /run/media/iyan/Data Y/Documents/Projects/Web/ayocode/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>
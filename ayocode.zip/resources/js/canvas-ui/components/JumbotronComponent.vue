<template>
	<div>	
		<h1>Blogs</h1>
    	<p class="lead text-secondary">Let's code the world</p>
	</div>
</template>

<script>

export default {
	name: "JumbotronBlog",
}
	
</script>

<style scoped>
/* h1 {
	font-family: 'Kirang Haerang', cursive;
	font-size: 60px;
	color: rgb(120, 59, 161);
} */
</style>